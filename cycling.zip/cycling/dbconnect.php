<?php
 //database connection variables for your UOS webspace database
 $servername = "localhost:3306";
 $username = "bh97vg";
 $password = "BrunoNoNoNo@2004";
 $database = "admin123"; 
 ?>