<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search for a person</title>
    <style>
        body{
            font-family: Arial, Helvetica, sans-serif;
        }
    </style>
</head>
<body>
	<a href="index.html">Back to Homepage</a>
	
    <form action="search_result.php" method="post">
        <p>Search for a First name here</p>
        <input type="text" name= "firstname_search" placeholder="Search">
     
        <input type="submit">

    </form>
</body>
</html